import Express  from "express";

const app = Express()
app.use(Express.json())

//================PORTA DO SERVIDOR==================
app.listen(3000, () => {
    console.log("Servidor rodando na porta 3000");
});
//===================================================

let cliente = [];
let carros = [];
let servicos = [];
let agendamentos = [];

//=========================================================================
//metodo get
app.get('/cliente',(req, res) =>{
    // res.json('Clientes Localizados:')
    res.json(cliente)
})
//metodo get por id
app.get('/cliente/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    
    const indiceCliente = cliente.findIndex(cliente => cliente.id == id);
    if (indiceCliente < 0) {
        res.json({ mensagem: "Usuário não existe." });
        return;
    }
    res.json({Cliente: cliente[indiceCliente]});
})

//metodo post
app.post('/cliente', (req, res) => {
    console.log('Cadastra um novo cliente');
    console.log('Body requisição: ', req.body);
    
    // pegar os dados enviados pelo cliente
    const idCliente = req.body.id;
    const nomeCliente = req.body.nome 
    const TelefoneCliente = req.body.fone;
    

    console.log('Id Cliente:', idCliente);
    console.log('Nome Cliente:', nomeCliente);
    console.log('Telefone Cliente:', TelefoneCliente);

    const Clientes = {
        id: idCliente,
        nome: nomeCliente,
        telefone: TelefoneCliente,
     
    };
    cliente.push(Clientes);
    res.json({ mensagem: 'Clientes cadastrado com sucesso.' });
});

//metodo delete
app.delete('/cliente/:id', (req, res) => {
    
    const id = req.params.id;
    console.log(id);

    // remover o usuário da lista
    const indiceCliente = cliente.findIndex(cliente => cliente.id == id);
    if (indiceCliente < 0) {
        res.json({ mensagem: "Cliente não existe." });
        return;
    }
    cliente.splice(indiceCliente, 1);

    res.json({ mensagem: 'Cliente removido com sucesso' });
});

//metodo put
app.put('/cliente/:id', (req, res) => {

})

//=========================================================================

//metodo get
app.get('/carros',(req, res) =>{
    res.json(carros)
})
//metodo get por id
app.get('/carros/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    
    const indiceCarros = carros.findIndex(carros => carros.id == id);
    if (indiceCarros < 0) {
        res.json({ mensagem: "carro não existe." });
        return;
    }
    res.json({Carros: carros[indiceCarros]});
})

//metodo post
app.post('/carros', (req, res) => {
    console.log('Cadastra um novo carro');
    console.log('Body requisição: ', req.body);
    
    // pegar os dados enviados pelo cliente
    const idCarro= req.body.id;
    const marcaCarro = req.body.marca 
    const modeloCarro = req.body.modelo;
    const tamanhoCarro = req.body.tamanho;
    const idCliente = req.body.cliente;

    console.log('Id do Carro:', idCarro);
    console.log('Nome do Carro:', marcaCarro);
    console.log('Modelo do Carro:', modeloCarro);
    console.log('Tamanho do Carro:', tamanhoCarro);
    console.log('Id do Cliente:', idCliente);


    const Carros = {
        id: idCarro,
        marca: marcaCarro,
        modelo: modeloCarro,
        tamanho: tamanhoCarro,
        cliente: idCliente
    };

    carros.push(Carros);
    res.json({ mensagem: 'Carros cadastrado com sucesso.'});
});

//metodo delete
app.delete('/carros/:id', (req, res) => {
    
    const id = req.params.id;
    console.log(id);

    // remover o usuário da lista
    const indiceCarros = carros.findIndex(carros => carros.id == id);
    if (indiceCarros < 0) {
        res.json({ mensagem: "carro não existe." });
        return;
    }
    carros.splice(indiceCarros, 1);

    res.json({ mensagem: 'carro removido com sucesso' });
});

//metodo put
app.put('/carros/:id', (req, res) => {

})

//=========================================================================

//metodo get
app.get('/servicos',(req, res) =>{
    res.json(servicos)
})
//metodo get por id
app.get('/servicos/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    
    const indiceServicos = servicos.findIndex(servicos => servicos.id == id);
    if (indiceServicos < 0) {
        res.json({ mensagem: "servicos não existe." });
        return;
    }
    res.json({Servicos: servicos[indiceServicos]});
})

//metodo post
app.post('/servicos', (req, res) => {
    console.log('Cadastra um novo servico');
    console.log('Body requisição: ', req.body);
    
    // pegar os dados enviados pelo cliente
    const idServico= req.body.id;
    const desServico = req.body.descricao 
    const ValorServico = req.body.valor;

    console.log('Id do Serviço:', idServico);
    console.log('Descricao do Serviço:', desServico);
    console.log('Valor do Serviço:', ValorServico);

    const Servico = {
        id: idServico,
        descricao: desServico,
        valor: ValorServico,
    };

    servicos.push(Servico);
    res.json({ mensagem: 'Serviço cadastrado com sucesso.'});
});

//metodo delete
app.delete('/servicos/:id', (req, res) => {
    
    const id = req.params.id;
    console.log(id);

    // remover o usuário da lista
    const indiceServicos = servicos.findIndex(servicos => servicos.id == id);
    if (indiceServicos < 0) {
        res.json({ mensagem: "servico não existe." });
        return;
    }
    servicos.splice(indiceServicos, 1);

    res.json({ mensagem: 'servico removido com sucesso' });
});

//=========================================================================

//metodo get
app.get('/agendamentos',(req, res) =>{
    res.json(agendamentos)
})

//metodo post
app.post('/agendamentos', (req, res) => {
    console.log('Cadastra um novo agendamentos');
    console.log('Body requisição: ', req.body);
    
    const idAgendamentos = req.body.id;
    const idCarro = req.body.idCarro;
    const idServico = req.body.idServico; 
    const dataHora = req.body.dataHora;
    
    console.log('Id_Agendamento:', idAgendamentos);
    console.log('Id_carro:', idCarro);
    console.log('Id_serviço:', idServico);
    console.log('Data e hora:', dataHora);

    const Agendamentos = {
        id: idServico,
        idCarro: idCarro,
        idServico: idServico,
        dataHora: dataHora,
    };

    agendamentos.push(Agendamentos);
    res.json({ mensagem: 'Agendamento cadastrado com sucesso.'});
});

module.exports = app;